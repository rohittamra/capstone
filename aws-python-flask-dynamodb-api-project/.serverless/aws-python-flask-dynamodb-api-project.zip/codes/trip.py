from flask import request
import boto3
from flask import Flask
import json
from flask import Blueprint
from datetime import datetime

tripnamespace = Blueprint('trip', __name__)
ddb = boto3.resource('dynamodb')
trip_table= ddb.Table('trips')


@tripnamespace.route('/getalltrips', methods=['GET'])
def getalltrips():
        trips = trip_table.scan()['Items']
        return (
			json.dumps(trips),
			200,
			{'Content-type': "application/json"}
		)
        
#Dont call this endpoint directly , instead call other booktaxi in user
@tripnamespace.route('/addtrip', methods=['POST'])
def addtrip():
        trip_table.put_item(Item=json.loads(request.data))
        return (
            json.dumps({'Message': 'trip entry created'}),
            200,
            {'Content-type': "application/json"}
        )
  
@tripnamespace.route('/getparticulartrip/<trip_id>', methods=['GET'])
def getlocationtaxistaxiid(trip_id):
    key = {'trip_id': trip_id}
    trip = trip_table.get_item(Key=key).get('Item')
    if trip:
        return json_response(trip)
    else:
        return json_response({"message": "taxi not found"}, 404)

#Dont call this endpoint directly , instead call other bookingdone in user
@tripnamespace.route('/edittrip/<trip_id>', methods=['PATCH'])
def edituseruserid(trip_id):

    json_loaded=json.loads(request.data)
    attribute_updates_dict = ({
            'money_paid': json_loaded["money_paid"],
            'method_of_transaction': json_loaded["method_of_transaction"],
            'start_location': json_loaded["start_location"],
            'end_location': json_loaded["end_location"],
            'kms_covered': json_loaded["kms_covered"],
            'start_location': json_loaded["start_location"],
            'time_of_end': str(datetime.now()),
        })
    attribute_updates = {key: {'Value': value, 'Action': 'PUT'}
                            for key, value in attribute_updates_dict.items()}
    trip_table.update_item( Key={'trip_id': trip_id },  AttributeUpdates=attribute_updates )
    return json_response({"message": "trip is editted successfully"})

def json_response(data, response_code=200):
    return json.dumps(data), response_code, {'Content-Type': 'application/json'}